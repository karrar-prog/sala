<?php
/**
 * Created by PhpStorm.
 * User: Emad
 * Date: 9/9/2018
 * Time: 8:42 AM
 */

return [
    "app_name" => "سلة الخير",
    "message_not_found" => "لايوجد هناك اي محتوى جديد",
    "btn_accept" => "قبول",
    "btn_reject" => "رفض",
    "btn_delete" => "حذف",

    //majales
    "majles_not_found"            => "المجلس غير موجود، اعد المحاولة لاحقاً.",
    "majles_error_connection"     => "يرجى التحقق من اتصال الإنترنت.",

    "accept_majles_success_true"  => "تم القبول بنجاح.",
    "accept_majles_success_false" => "لم يتم القبول، اعد المحاولة لاحقاً.",

    "reject_majles_success_true"  => "تم الرفض بنجاح.",
    "reject_majles_success_false" => "لم يتم الرفض، اعد المحاولة لاحقاً.",

    "delete_majles_success_true"  => "تم الحذف بنجاح.",
    "delete_majles_success_false" => "لم يتم الحذف، اعد المحاولة لاحقاً.",
];