@extends("layout.vue-layout")
@section("content")
<router-view name="ReceptionIndex"></router-view>
<router-view></router-view>
@endsection