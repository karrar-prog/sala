@extends("CP.layout.layout")

@section("content")
    <div class="container">
        <div class="row">
            <div class="col-12 d-flex justify-content-around">
                <a class="btn btn-primary btn-lg p-5" href="/control-panel/center/add-lost">اضافة تائه او مفقود</a>
                <a class="btn btn-primary btn-lg p-5" href="/lost">عرض المفقودات والتائهين</a>
            </div>
        </div>
    </div>
@endsection

@section("script")
    <script>

    </script>
@endsection