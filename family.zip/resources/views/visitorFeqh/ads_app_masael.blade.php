<div class="col-12 pb-2">
    <div class="alert alert-warning border-warning text-center shadow-sm">
        <h6 class="font-height-normal">{{trans("words.visitor_feqh_ads_app_masael_text")}}</h6>
        <p class="py-2 m-0">
            <span> {{trans("words.visitor_feqh_ads_app_masael_detail")}} </span>
            <span class="btn-link" id="learn-more" style="cursor: pointer;">
                {{trans("words.visitor_feqh_ads_app_masael_btn")}}
            </span>
        </p>
    </div>
</div>