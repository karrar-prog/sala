



<div class="modal fade" id="modal-dialog-centered" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-image" role="document">
        <img src="" class="w-100 h-100 image" id="image" style="position: relative">
    </div>
</div>