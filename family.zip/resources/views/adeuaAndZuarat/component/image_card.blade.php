



<div class="gallery-images col-md-6 p-0">
    <img src="{{asset('storage/img/studio')}}/{{$image->image}}"
         class="image w-100 h-100" data-toggle="modal"
         data-target="#modal-dialog-centered">
    {{$slot}}
</div>