



<div class="row p-0 pb-4">
    <div class="col-md-12 shadow-special p-0">
        <div class="p-3" style="background-color: #b8daff">
            <h2>{{$postTitle}}</h2>
        </div>
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="{{$postVideoLink}}" allowfullscreen></iframe>
        </div>
    </div>
</div>