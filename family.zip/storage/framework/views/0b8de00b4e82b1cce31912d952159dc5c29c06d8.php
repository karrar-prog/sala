<style>
    <?php switch(app()->getLocale()):
        case ("ar"): ?> body {direction: rtl; text-align: right;} <?php break; ?>
        <?php case ("fa"): ?> body {direction: rtl; text-align: right;} <?php break; ?>
        <?php case ("en"): ?> body {direction: ltr; text-align: left;} <?php break; ?>
        <?php default: ?>    body {direction: rtl; text-align: right;}
    <?php endswitch; ?>
</style>