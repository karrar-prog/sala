<div class="row" id="lost-centers-points">
    <div class="col-12">
        <ul class="timeline">
            <?php $i=1; ?>
            <?php $__currentLoopData = $lostCenterPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li <?php if($i%2==1): ?> class="timeline-inverted" <?php endif; ?>>
                <div class="timeline-badge shadow <?php echo e(\App\Enums\PointCategory::getCategoryColor($point->category)); ?>"
                     data-action="show-calculate-distance-modal" data-t_number="<?php echo e($point->t_number); ?>">
                    <i class="fa <?php echo e(\App\Enums\PointCategory::getCategoryIcon($point->category)); ?>"></i>
                </div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h5 class="timeline-title"><?php echo e($point->name); ?></h5>
                        <p class="m-0">
                            <small>
                                <span><?php echo e(trans("words.road_guide_card_corresponding_column_number")); ?></span>
                                <i class="fa fa-caret-left align-middle "></i>
                                <span><?php echo e($point->t_number); ?></span>
                            </small>
                        </p>
                        <a href="javascript:void(0);" class="location" data-latitude="<?php echo e($point->latitude); ?>" data-longitude="<?php echo e($point->longitude); ?>">
                            <small><?php echo e(trans("words.road_guide_card_show_location_on_google_map")); ?></small>
                        </a>
                    </div>
                    <div class="timeline-body">
                        <div class="alert alert-primary d-none" data-calculate="false">
                            <p>
                                <span><?php echo e(trans("words.road_guide_calculate_distance_estimated_distance")); ?></span>
                                <span> : </span>
                                <span class="data-estimated-distance"></span>
                            </p>

                            <p>
                                <span><?php echo e(trans("words.road_guide_calculate_distance_estimated_time")); ?></span>
                                <span> : </span>
                                <span class="data-estimated-time"></span>
                            </p>

                            <p>
                                <span><?php echo e(trans("words.road_guide_calculate_distance_number_of_column")); ?></span>
                                <span> : </span>
                                <span class="data-number-of-column"></span>
                            </p>

                            <p class="mb-0">
                                <span><?php echo e(trans("words.road_guide_calculate_distance_direction")); ?></span>
                                <span> : </span>
                                <span class="data-direction"></span>
                            </p>
                        </div>
                        <p class="m-0"><?php echo e($point->description); ?></p>
                    </div>
                </div>
            </li>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>