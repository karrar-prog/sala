<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>لوحة تحكم حقيبة الزائر </title>

    <!-- StyleSheet -->
    <link href="<?php echo e(asset("css/app.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("css/cp_style.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("css/snackbar.css")); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <!-- Script -->
    <script src="<?php echo e(asset("js/jquery-3.3.1.min.js")); ?>"></script>
    <script src="<?php echo e(asset("js/app.js")); ?>"></script>
    <script src="<?php echo e(asset("js/snackbar.js")); ?>"></script>

    <?php echo $__env->make("CP.layout.body_direction", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    
    <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
        <a class="navbar-brand" href="javascript:void(0);">
          لوحة التحكم
        </a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarCollapse" style="">
            <ul class="navbar-nav mr-auto">

            </ul>
        </div>
    </nav>

    
    <?php echo $__env->yieldContent("content"); ?>

    
    <?php echo $__env->yieldContent("script"); ?>
</body>
</html>