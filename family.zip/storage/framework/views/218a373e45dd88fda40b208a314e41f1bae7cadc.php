<?php $__env->startSection("navbar-brand"); ?>
    <span id="title"><?php echo e(trans('words.adeua-and-zuarat-adeua-title')); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container prayerAndVisits pt-3 pb-2">
        <div>
            <?php $__env->startComponent('adeuaAndZuarat.component.search' , ['routeName'=>'searchByAdeua']); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="row justify-content-center pt-2 pb-5">
            <?php $__env->startComponent('adeuaAndZuarat.component.deua_today_card' , ['daysAdeua' => $daysAdeua]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="row">
            <?php $__currentLoopData = $publicAdeua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicDeua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->startComponent('adeuaAndZuarat.component.deua_card'); ?>
                    <?php $__env->slot('titleID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('title'); ?>
                        <?php echo e($publicDeua->title); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('contentID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('content'); ?>
                        <?php echo e($publicDeua->content); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('readingCollapseID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('readingTrans'); ?>
                        <?php echo e(trans("words.adeua-and-zuarat-main-btn-reading-deua")); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('btnReadingValue'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('listenCollapseID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('sound'); ?>
                        <?php echo e($publicDeua->sound); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('listenTrans'); ?>
                        <?php echo e(trans("words.adeua-and-zuarat-main-btn-listen-deua")); ?>

                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="d-flex justify-content-center py-2">
            <?php echo e($publicAdeua->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>





<?php $__env->startSection('script'); ?>
    <script>
        var readMore = $('.read-more');
        readMore.on('click' , function () {
            var id = $(this).attr('value');
            var content = $('#cont-'+id).text();
            var title = $('#tit-'+id).text();
            $('#modal-title').text(title);
            $('#modal-content').text(content)
        })
    </script>
    <script>
        $(document).ready(function () {
            $('.carousel-item:first').addClass('active');
        })
    </script>
    <script>
        document.addEventListener('play', function(e){
            var audios = document.getElementsByTagName('audio');
            for(var i = 0, len = audios.length; i < len;i++){
                if(audios[i] !== e.target){
                    audios[i].pause();
                }
            }
        }, true);
    </script>
    <script>
        $(document).ready(function () {
            $('#zoomIn').on('click' ,function () {
                var fontSize = $('.font-size');
                var fontSizePluse = parseFloat(fontSize.css('font-size'));
                fontSizePluse = fontSizePluse + 1;
                fontSize.css('font-size',fontSizePluse+'px');
            });
            $('#zoomOut').on('click' , function () {
                var fontSize = $('.font-size');
                var fontSizeMinus = parseFloat(fontSize.css('font-size'));
                fontSizeMinus = fontSizeMinus - 1;
               if (fontSizeMinus >13)
               {
                   fontSize.css('font-size',fontSizeMinus+'px');
               }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adeuaAndZuarat.component.main_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adeuaAndZuarat.component.content_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.secondary_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>