



<div class="modal fade exampleModalLong" id="exampleModalLong"
     tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLongTitle"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 id="modal-title"></h4>
            </div>
            <div class="modal-body">
                <p id="modal-content" style="font-size:17px;line-height: 2.5"></p>
            </div>
            <div class="modal-footer align-self-start border-0">
                <button type="button" class="btn btn-secondary rounded" data-dismiss="modal">
                    <?php echo e(trans("words.adeua-and-zuarat-main-btn-modal-close")); ?>

                </button>
            </div>
        </div>
    </div>
</div>