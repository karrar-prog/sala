<div class="modal fade" id="menu-modal" tabindex="-1" role="dialog" aria-labelledby="menu-modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-special" role="document">
        <?php echo $__env->yieldContent("menu-modal-content"); ?>
    </div>
</div>