<?php $__env->startSection("content"); ?>
    <?php if(session('message')): ?>
        <div class="col">
        </div>
        <div class="col">
            <div class="alert alert-success w-100" role="alert">
                <?php echo e(session('message')); ?>

            </div>

        </div>
        <div class="col">
        </div>
    <?php endif; ?>


    <div >

     <a href="/123456789123456789/new_point"><i  class="rounded-circle m-4 fa fa-plus-circle fa-3x shadow"></i></a>

    </div>

<div class="container col-7 mb-4" style="margin-top: -95px">

    <?php echo $__env->make("items.cities", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <div class="container">
                <div class="row">

                    <div class="col-sm-5 ">
                        <?php echo e($point->name); ?>


                    </div>
                    <div class="col-sm">
                        <?php if($point->category == 1): ?>
                        موكب
                        <?php elseif($point->category == 2): ?>
                      حمامات
                        <?php elseif($point->category == 3): ?>
                            نقاط عامة
                        <?php elseif($point->category == 4): ?>
                            مركز مفقودين
                        <?php elseif($point->category == 5): ?>
                            مركز استفتاء
                        <?php elseif($point->category == 6): ?>
                            مركز صحي
                        <?php endif; ?>


                    </div>
                    <div class="col-sm">
                        <a href="/123456789123456789/edit_point/<?php echo e($point->id); ?>" class="btn btn-success"><i class="fa fa-edit  "> تعديل </i></a>
                        <a href="/123456789123456789/ensure_delete/<?php echo e($point->id); ?>"  class="btn btn-primary"><i class="fa fa-trash-alt  "> حذف </i></a>
                    </div>
                </div>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("CP.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>