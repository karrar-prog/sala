<label for="input_city">اختيار الطريق</label>

<select  id="input_city" name="city" class="form-control">
    <option selected value="0">نجف - كربلاء</option>
    <option  value="1">حلة - كربلاء</option>
    <option  value="2">مسيب - كربلاء</option>
</select>
