<?php $__env->startSection("content"); ?>
        <router-view name="LostIndex"></router-view>
        <router-view></router-view>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("nav-items-bottom"); ?>
    <a class="nav-item nav-link rounded-0" href="/"><i class="fa fa-road text-white"></i></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.vue-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>