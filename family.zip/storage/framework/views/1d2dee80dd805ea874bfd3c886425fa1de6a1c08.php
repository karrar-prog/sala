<?php $__env->startSection("navbar-color"); ?>
    <?php echo e("bg-orange-gradient"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("navbar-brand"); ?>
    <span id="title">المجالس - عرض الجميع</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-2 pb-2">
        <?php if($events->count() == 0): ?>
            <div class="mt-lg-5 text-center">
                <h1>لاتوجد بيانات لعرضها</h1>
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__env->startComponent('majales.component.majles_card', ['event'=>$event]); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>
            <?php echo e($events->links()); ?>

        </div>
    </div>

    <?php $__env->startComponent('majales.component.main_menu'); ?>
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('majales.component.maps_modal'); ?>
    <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDKYUdCrdRfLxHyfmp7DioNrGMOt7fI-E4">

    </script>
    <script>
        function initialize(x,y) {
            let center = new google.maps.LatLng(x,y);
            let mapOptions = {
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                center: center
            };

            map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

        }

        $('.location').on('click', function () {
            $('#modal').modal({
                backdrop: 'static',
                keyboard: false
            });
            initialize($(this).attr('data-latitude'),$(this).attr('data-longitude'));
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.secondary_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>