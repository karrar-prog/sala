<?php $__env->startSection("content"); ?>
    <div class="container" style="margin-top: 60px;">
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <form class="col-12 col-sm-6 bg-white text-center border shadow-sm p-5" action="/login" method="post">
                    <p class="h4 mb-4">تسجيل دخول</p>

                    <?php if(count($errors)): ?>
                        <div class="alert alert-danger text-right">
                            <ul class="pr-3 mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="my-1"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session("ErrorLoginMessage")): ?>
                        <div class="alert alert-danger text-center"><?php echo e(session("ErrorLoginMessage")); ?></div>
                    <?php endif; ?>

                    <?php echo e(csrf_field()); ?>

                    <input type="text"     name="username" class="form-control mb-4" placeholder="اسم المستخدم">
                    <input type="password" name="password" class="form-control mb-4" placeholder="كلمة المرور">

                    <P class="mb-4 d-flex justify-content-start">
                        <a href="/register">او قم بانشاء حساب</a>
                    </P>

                    <button class="btn btn-vg-light btn-block my-4" type="submit">تسجيل دخول</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.primary_layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>