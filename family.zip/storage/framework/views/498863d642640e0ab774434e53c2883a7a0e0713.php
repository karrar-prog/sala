<label for="input_city">المحافظة</label>

<select  id="input_city" name="city" class="form-control">
    <option selected value="0">النجف</option>
    
    
</select>
