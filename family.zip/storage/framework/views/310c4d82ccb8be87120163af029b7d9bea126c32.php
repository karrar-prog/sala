<?php $__env->startSection("navbar-color"); ?>
    <?php echo e("bg-aqua-gradient"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("navbar-brand"); ?>
    <span id="title"><?php echo e(trans('words.deua-and-zuarat-main-menu-videos-gallery')); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container prayerAndVisits pt-2 pb-2">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__env->startComponent('adeuaAndZuarat.component.video_card'); ?>
                <?php $__env->slot('postTitle'); ?>
                    <?php echo e($post->title); ?>

                <?php $__env->endSlot(); ?>
                <?php $__env->slot('postVideoLink'); ?>
                    <?php echo e($post->video_link); ?>

                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($posts->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.secondary_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>