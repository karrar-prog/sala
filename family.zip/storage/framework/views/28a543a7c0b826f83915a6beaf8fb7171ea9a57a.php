<?php $__env->startSection('top-title'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("navbar-color"); ?>
    <?php echo e("bg-aqua-gradient"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("navbar-brand"); ?>
    <span id="title"><?php echo e(trans('words.adeua-and-zuarat-adeua-title')); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container prayerAndVisits pt-3 pb-2">
        <div>
            <?php $__env->startComponent('adeuaAndZuarat.component.search' , ['routeName'=>'searchByAdeua']); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="row justify-content-center pt-2 pb-5">
            <?php if($publicAdeua->count() == 0): ?>
                <div class="row justify-content-center">
                    <div>
                        <h2><?php echo e(trans('words.adeua-zuarat-no-data')); ?></h2>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <?php $__currentLoopData = $publicAdeua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicDeua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->startComponent('adeuaAndZuarat.component.deua_card'); ?>
                    <?php $__env->slot('titleID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('title'); ?>
                        <?php echo e($publicDeua->title); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('contentID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('content'); ?>
                        <?php echo e($publicDeua->content); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('readingCollapseID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('readingTrans'); ?>
                        <?php echo e(trans("words.adeua-and-zuarat-main-btn-reading-deua")); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('btnReadingValue'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('listenCollapseID'); ?>
                        <?php echo e($publicDeua->id); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('sound'); ?>
                        <?php echo e($publicDeua->sound); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('listenTrans'); ?>
                        <?php echo e(trans("words.adeua-and-zuarat-main-btn-listen-deua")); ?>

                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div>
            <?php echo e($publicAdeua->links()); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>





<?php $__env->startSection('script'); ?>
    <script>
        let readMore = $('.read-more');
        readMore.on('click' , function () {
            let id = $(this).attr('value');
            let content = $('#cont-'+id).text();
            let title = $('#tit-'+id).text();
            $('#modal-title').text(title);
            $('#modal-content').text(content)
        })
    </script>
    <script>
        document.addEventListener('play', function(e){
            let audios = document.getElementsByTagName('audio');
            for(let i = 0, len = audios.length; i < len;i++){
                if(audios[i] !== e.target){
                    audios[i].pause();
                }
            }
        }, true);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adeuaAndZuarat.component.main_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adeuaAndZuarat.component.content_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.secondary_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>