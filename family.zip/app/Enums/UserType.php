<?php
/**
 * Created by PhpStorm.
 * User: Emad
 * Date: 7/30/2018
 * Time: 10:05 AM
 */

namespace App\Enums;


class UserType
{
    const MAJALES = 1;
    const VISITOR_RECEPTION = 2;
}