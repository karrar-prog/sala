<?php
/**
 * Created by PhpStorm.
 * User: Emad
 * Date: 7/30/2018
 * Time: 8:48 AM
 */

namespace App\Enums;


class AdeuaZuaratCategory
{
    const ZUARAT = 1;
    const PUBLIC_ADEUA = 2;
    const DAYS_ADEUA = 3;
}