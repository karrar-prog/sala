<?php
/**
 * Created by PhpStorm.
 * User: Emad
 * Date: 9/9/2018
 * Time: 12:05 PM
 */

namespace App\Enums;


class MajlesStatus
{
    const NO_ACTIVE = 0;
    const ACCEPT = 1;
    const REJECT = 2;
}