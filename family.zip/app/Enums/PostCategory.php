<?php
/**
 * Created by PhpStorm.
 * User: Emad
 * Date: 7/30/2018
 * Time: 10:50 AM
 */

namespace App\Enums;


class PostCategory
{
    const MAJALES = 1;
    const ADEUA_ZUARAT = 2;
}