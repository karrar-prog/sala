<?php
/**
 * Created by PhpStorm.
 * User: domka
 * Date: 2018-08-18
 * Time: 09:52
 */

namespace App\Enums;


class VisitorReception
{
    const men = "رجال";
    const women = "نساء";
    const family = "عوائل";

    const  food = "يوجد طعام";
    const no_food = "لايوجد طعام";


}