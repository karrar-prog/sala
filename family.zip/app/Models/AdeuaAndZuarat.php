<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdeuaAndZuarat extends Model
{
    protected $table = "adeua_zuarat";
    protected $primaryKey = "id";
    public $timestamps = false;
}
